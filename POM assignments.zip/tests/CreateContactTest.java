package tests;

import org.testng.annotations.Test;

//import createcontactpage.ContactsPage;
//import createcontactpage.HomePage1;
import createcontactpage.LoginPage1;
import hooks.BasePage;
//import screens.LoginPage;

public class CreateContactTest extends BasePage{
	@Test
	public void createContactTest() {
		new LoginPage1()
		.typeUserName()
		.typePassword()
		.clickLogin1()
	//	new HomePage1(driver)
		.clickCRMSFA()
	//	new ContactsPage(driver)
		.clickContacts()
		.clickCreateContact()
		.typeFirstName()
		.typeLastName()
		.typeFirstNameLocal()
		.typeLastNameLocal()
		.typeDepartmentName()
		.typeDescription()
		.typeprimaryEmail()
		.typegeneralStateProvinceGeoId()
		.clickCreateContactButton()
		.clickEditButton()
		.clearAndTypeDescription()
		.clickUpdateContact()
		.verifyContact();
		
		


		
		
		
		
		
	}

}
