package tests;

import org.testng.annotations.Test;

import editleadpage.LoginPage2;
import hooks.BasePage;

public class EditLeadTest extends BasePage{
	@Test
	public void EditLeadTest() throws InterruptedException {
		new LoginPage2()
		.typeUserName()
		.typePassword()
		.clickLogin2()
		.clickCRMSFA2()
		.clickLeadsButton()
		.clickFindLeads()
		.typeFirstName()
		.clickFindLeadsButton()
		.clickFirstLeadId()
		.clickEditButton1()
		.clearCompanyName()
		.updateCompanyName()
		.clickUpdateButton1()
		.verifyUpdatedCompanyName();
		
	}

}
