package tests;

import org.testng.annotations.Test;

import duplicateleadpage.LoginPage3;
import editleadpage.LoginPage2;
import hooks.BasePage;

public class DuplicateLeadTest extends BasePage {
	@Test
	public void DuplicateLeadTest() throws InterruptedException {
		new LoginPage3()
		.typeUserName()
		.typePassword()
		.clickLogin3()
		.clickCRMSFA3()
		.clickLeadsButton3()
		.clickFindLeads3()
		.clickEmail1()
		.typeEmailAddress3()
		.clickFindLeadsButton4()
		.clickFirstLeadId3()
		.clickDuplicateButton2()
		.verifyDuplicateLead3()
		.clickCreateLead3()
		.viewLead_FirstName()
		.verify_Captured_LeadId();
	}	

}
