package tests;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import hooks.BasePage;
import screens.LoginPage;

public class S12_1021_Login extends BasePage{
	
	
	@Test
	public void loginTest() {
		
		 new LoginPage(driver)
		.typeUserName()
		.typePassword()
		.clickLogin()
		.clickCRMSFA()
		.clickLeadsTab()
		.clickcreateLead()
		.enterCompanyName()
		.enterFirstName()
		.enterLastName()
		.clickSubmit()
		.verifyFirstName();
		
	}
	
}
