package createcontactpage;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import hooks.BasePage;

public class ViewMyCreateContactPage extends BasePage {
	public ViewMyCreateContactPage(ChromeDriver driver) {
		this.driver=driver;
	}
	public ViewMyCreateContactPage verifyContact() {
		String contactName = driver.findElement(By.id("viewContact_fullName_sp")).getText();
		System.out.println("Created Contact Name is :: "+contactName);
		return this;
	}
	

}
