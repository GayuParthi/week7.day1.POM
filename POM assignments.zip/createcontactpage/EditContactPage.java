package createcontactpage;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import hooks.BasePage;

public class EditContactPage extends BasePage{
	public EditContactPage(ChromeDriver driver) {
		this.driver=driver;
	}
	public EditContactPage clearAndTypeDescription() {
		driver.findElement(By.id("updateContactForm_description")).clear();
		driver.findElement(By.id("updateContactForm_importantNote")).sendKeys("Confidential");
		return this;
	}
	public ViewMyCreateContactPage clickUpdateContact() {
		driver.findElement(By.xpath("//input[@value='Update']")).click();
		return new ViewMyCreateContactPage(driver);
	}
	

}
