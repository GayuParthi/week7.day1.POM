package createcontactpage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import hooks.BasePage;

public class MyContactDetails extends BasePage{
	public MyContactDetails(ChromeDriver driver) {
		this.driver=driver;
	}
	public MyContactDetails typeFirstName() {
		WebElement elementFirstName = driver.findElement(By.id("firstNameField"));
		elementFirstName.sendKeys("Abinaya");
		return this;
		
	}
	public MyContactDetails typeLastName() {
		driver.findElement(By.id("lastNameField")).sendKeys("Shree");
		return this;
	}
	public MyContactDetails typeFirstNameLocal() {
		driver.findElement(By.id("createContactForm_firstNameLocal")).sendKeys("Sudheera");
		return this;
	}
	public MyContactDetails typeLastNameLocal() {
		driver.findElement(By.id("createContactForm_lastNameLocal")).sendKeys("Shri");
		return this;
	}
	public MyContactDetails typeDepartmentName() {
		driver.findElement(By.id("createContactForm_departmentName")).sendKeys("EIE");
		return this;
	}
	public MyContactDetails typeDescription() {
		driver.findElement(By.id("createContactForm_description")).sendKeys("Electronics and Instrumentation Engineering");
		return this;
	}
	public MyContactDetails typeprimaryEmail() {
		driver.findElement(By.id("createContactForm_primaryEmail")).sendKeys("sudheera96@gmail.com");
		return this;
	}
	public MyContactDetails typegeneralStateProvinceGeoId() {
		WebElement state = driver.findElement(By.id("createContactForm_generalStateProvinceGeoId"));
		Select obj = new Select(state);
		obj.selectByVisibleText("New York");
		return this;
	}
	public ViewContactPage clickCreateContactButton() {
		driver.findElement(By.className("smallSubmit")).click();
		return new ViewContactPage(driver);
	}
	
	
	

}
