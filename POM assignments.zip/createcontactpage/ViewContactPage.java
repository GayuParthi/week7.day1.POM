package createcontactpage;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import hooks.BasePage;

public class ViewContactPage extends BasePage {
	public ViewContactPage(ChromeDriver driver) {
		this.driver=driver;
	}
	public EditContactPage clickEditButton() {
		driver.findElement(By.linkText("Edit")).click();
		return new EditContactPage(driver);
	}

}
