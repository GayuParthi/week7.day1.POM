package createcontactpage;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import hooks.BasePage;

public class ContactsPage extends BasePage {
	public ContactsPage(ChromeDriver driver) {
		this.driver=driver;
	}
	public ContactsPage clickContacts() {
		driver.findElement(By.partialLinkText("Contacts")).click();
		return this;
	}
	public MyContactDetails clickCreateContact() {
		driver.findElement(By.partialLinkText("Create Contact")).click();
		return new MyContactDetails(driver);
	}

}
