package editleadpage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import hooks.BasePage;

public class LoginPage2 extends BasePage{
	public void LoginPage2(ChromeDriver driver) {
		this.driver=driver;
	}
	
	
	/**
	 * Type the user name in the login screen
	 * @param userId -- The different username to login
	 * @return 
	 */
	public LoginPage2 typeUserName() {
		driver.findElement(By.id("username")).sendKeys("DemoCSR");
		
		return this;
	}
	
	/**
	 * Type the password in the login screen
	 * @param password -- The different password to login
	 * @return 
	 */
	

	
	public LoginPage2 typePassword() {
		driver.findElement(By.id("password")).sendKeys("crmsfa");
		
		return this; 
	}
	
	/**
	 * Click the login button
	 * @return 
	 */
	public HomePage2 clickLogin2() {
		driver.findElement(By.className("decorativeSubmit")).click();
		return new HomePage2(driver);
	}

}







