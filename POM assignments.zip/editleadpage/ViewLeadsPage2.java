package editleadpage;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import hooks.BasePage;

public class ViewLeadsPage2 extends BasePage {
	public ViewLeadsPage2(ChromeDriver driver) {
		this.driver=driver;
	} 
	public ViewLeadsPage2 verifyUpdatedCompanyName() {
		String companyName = driver.findElement(By.id("viewLead_companyName_sp")).getText();
		System.out.println("Updated Company Name :: "+companyName);
		String firstName = driver.findElement(By.id("viewLead_firstName_sp")).getText();
		System.out.println("First Name Of the Lead:: "+firstName);
		return this;
	}
	

}
