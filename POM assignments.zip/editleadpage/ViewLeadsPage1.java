package editleadpage;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import hooks.BasePage;

public class ViewLeadsPage1 extends BasePage{
	public ViewLeadsPage1(ChromeDriver driver) {
		this.driver=driver;
	}
	public EditLeadPage1 clickEditButton1() {
		driver.findElement(By.xpath("//a[text()='Edit']")).click();
		return new EditLeadPage1(driver);

	}

}
