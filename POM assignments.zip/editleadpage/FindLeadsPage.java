package editleadpage;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import hooks.BasePage;

public class FindLeadsPage extends BasePage{
	public FindLeadsPage(ChromeDriver driver) {
		this.driver=driver;
	}
	public FindLeadsPage typeFirstName() {
		driver.findElement(By.xpath("(//input[@name='firstName'])[3]")).sendKeys("Hari");
		return this;
	}
	public FindLeadsPage clickFindLeadsButton() {
		driver.findElement(By.xpath("//button[text()='Find Leads']")).click();
		return this;
	}
	public ViewLeadsPage1 clickFirstLeadId() throws InterruptedException {
		driver.findElement(By.xpath("(//a[@href='/crmsfa/control/viewLead?partyId=10127'])")).click();
		Thread.sleep(2000);
		return new ViewLeadsPage1(driver);
	}
	

}
