package editleadpage;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import hooks.BasePage;

public class EditLeadPage1 extends BasePage {
	public EditLeadPage1(ChromeDriver driver) {
		this.driver=driver;
	}
	public EditLeadPage1 clearCompanyName() {
		driver.findElement(By.id("updateLeadForm_companyName")).clear();
		return this;
	}
	public EditLeadPage1 updateCompanyName() {
		driver.findElement(By.id("updateLeadForm_companyName")).sendKeys("TCS");
		return this;
	}
	public ViewLeadsPage2 clickUpdateButton1() {
		driver.findElement(By.xpath("(//input[@class='smallSubmit'])")).click();
		return new ViewLeadsPage2(driver);
	}
	

}
