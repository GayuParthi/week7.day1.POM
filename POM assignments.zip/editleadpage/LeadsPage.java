package editleadpage;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import hooks.BasePage;

public class LeadsPage extends BasePage {
	public LeadsPage(ChromeDriver driver) {
		this.driver=driver;
	}
	public LeadsPage clickLeadsButton() {
		driver.findElement(By.linkText("Leads")).click();
		return this;
	}
	public FindLeadsPage clickFindLeads() {
		driver.findElement(By.linkText("Find Leads")).click();
		return new FindLeadsPage(driver);
	}
	

}
