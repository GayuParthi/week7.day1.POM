package screens;

import org.openqa.selenium.By;

import org.openqa.selenium.chrome.ChromeDriver;

import hooks.BasePage;

public class CreateLeadPage extends BasePage {
	public CreateLeadPage(ChromeDriver driver) {
		this.driver=driver;
	}
	public CreateLeadPage enterFirstName() {
		driver.findElement(By.id("createLeadForm_firstName")).sendKeys("Gayathri");
		
		return this;
	}
	public CreateLeadPage enterLastName() {
		driver.findElement(By.id("createLeadForm_lastName")).sendKeys("SK");
		return this;
	}
	public CreateLeadPage enterCompanyName() {
		driver.findElement(By.id("createLeadForm_companyName")).sendKeys("TestLeaf");
		return this;
	}
	
public ViewLeadsPage clickSubmit() {
	driver.findElement(By.xpath("//input[@value='Create Lead']")).click();
	return new ViewLeadsPage(driver);
}
	
	
}
