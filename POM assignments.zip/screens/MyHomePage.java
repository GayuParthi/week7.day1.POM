package screens;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import hooks.BasePage;

public class MyHomePage extends BasePage{
	public void HomePage(ChromeDriver driver) {
		this.driver=driver;
	}
	/**
	 * This method is to click on CRM/SFA link in Home Page
	 * @return 
	 */

	public MyLeadsPage clickLeadsTab() {
		driver.findElement(By.linkText("Leads")).click();
		return new MyLeadsPage(driver);
	}
	
}
