package duplicateleadpage;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import hooks.BasePage;

public class DuplicateLeadPage1 extends BasePage{
	public DuplicateLeadPage1(ChromeDriver driver) {
		this.driver=driver;
	}
	public DuplicateLeadPage1 verifyDuplicateLead3() {
		if(driver.getTitle().contains("Duplicate Lead")) {
			System.out.println("The title contains the word Duplicate Lead");
		}else {
			System.out.println("The title does not contain the word Duplicate Lead");
		}
		return this;
	}
	public ViewleadsPage4 clickCreateLead3() {
		driver.findElement(By.name("submitButton")).click();
		return new ViewleadsPage4(driver);
	}
	

}
