package duplicateleadpage;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import editleadpage.FindLeadsPage;
import hooks.BasePage;

public class LeadsPage1 extends BasePage{
	public LeadsPage1(ChromeDriver driver) {
		this.driver=driver;
	}
	public LeadsPage1 clickLeadsButton3() {
		driver.findElement(By.linkText("Leads")).click();
		return this;
	}
	public FindLeadsPage1 clickFindLeads3() {
		driver.findElement(By.linkText("Find Leads")).click();
		return new FindLeadsPage1(driver);
	}

}
