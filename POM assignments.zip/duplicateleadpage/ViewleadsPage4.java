package duplicateleadpage;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import hooks.BasePage;

public class ViewleadsPage4 extends BasePage{
	String capturedLeadName;
	String duplicatedLeadName;
	public ViewleadsPage4(ChromeDriver driver) {
		this.driver=driver;
	}
	public ViewleadsPage4 viewLead_FirstName() {
		String duplicatedLeadName = driver.findElement(By.id("viewLead_firstName_sp")).getText();
		System.out.println(duplicatedLeadName);
		return this;
	}
	public ViewleadsPage4 verify_Captured_LeadId() {
		
		Object capturedLeadName = driver;
		Object duplicatedLeadName = driver;
		if(capturedLeadName.equals(duplicatedLeadName)) {
	    	System.out.println("Duplicated lead name is same as Captured name");
	    }else {
	    	System.out.println("Duplicated lead name is not same as Captured name");
	    }
		return this;
	}

}
