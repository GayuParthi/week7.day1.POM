package duplicateleadpage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import hooks.BasePage;

public class ViewLeadsPage3 extends BasePage{
	public ViewLeadsPage3(ChromeDriver driver) {
		this.driver=driver;
	} 
	public DuplicateLeadPage1 clickDuplicateButton2() {
		driver.findElement(By.linkText("Duplicate Lead")).click();
		return new DuplicateLeadPage1(driver);
	}
	
	

}
