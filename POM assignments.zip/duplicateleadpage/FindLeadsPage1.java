package duplicateleadpage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import hooks.BasePage;

public class FindLeadsPage1 extends BasePage{
	public FindLeadsPage1(ChromeDriver driver) {
		this.driver=driver;
	} 
	public FindLeadsPage1 clickEmail1() {
		driver.findElement(By.linkText("Email")).click();
		return this;
	}
	public FindLeadsPage1 typeEmailAddress3() {
		driver.findElement(By.name("emailAddress")).sendKeys("abc@gmail.com");
		return this;
	}
	public FindLeadsPage1 clickFindLeadsButton4() throws InterruptedException {
		driver.findElement(By.xpath("//button[contains(text(), 'Find Leads')]")).click();
		Thread.sleep(1000);
		return this;
	}
	public ViewLeadsPage3 clickFirstLeadId3() {
		WebElement leadFirstName = driver.findElement(By.xpath("(//div[@class='x-grid3-cell-inner x-grid3-col-firstName'])[1]/a"));
		String capturedLeadName = leadFirstName.getText();
		System.out.println(capturedLeadName);
		leadFirstName.click();
		return new ViewLeadsPage3(driver);
	}

}
