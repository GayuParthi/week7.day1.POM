package duplicateleadpage;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import hooks.BasePage;
//import screens.MyHomePage;

public class HomePage3 extends BasePage{
	public HomePage3(ChromeDriver driver) {
		this.driver=driver;
	}
		
	/**
	 * This method is to click on CRM/SFA link in Home Page
	 * @return 
	 */
	public LeadsPage1 clickCRMSFA3() {
		driver.findElement(By.linkText("CRM/SFA")).click();
		return new LeadsPage1 (driver);
	}

}
